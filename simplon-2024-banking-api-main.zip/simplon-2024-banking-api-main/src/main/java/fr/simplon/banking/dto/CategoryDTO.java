package fr.simplon.banking.dto;

import lombok.Data;

@Data
public class CategoryDTO {
    private String name;
    private String color;
    private String limit;
}
